import tkinter
import customtkinter
from pytube import Youtube 

#System Settings 
customtkinter.set_appearance_mode("System")
customtkinter.set_default_color_theme("blue")

#App frame
app = customtkinter.CTk()
app.geometry("720x48")
