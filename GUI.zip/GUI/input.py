import tkinter as tk

root = tk.Tk()
root.title("Tkinter")
root.geometry("300x150")


entry = tk.Entry(root)
entry.place(x=80, y=40)

root.mainloop()
